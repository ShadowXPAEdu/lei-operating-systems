#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/types.h>
#include "msgdist.h"
#include "msgdist_c.h"

int main(int argc, char* argv[], char** envp) {


        if (argc != 2) {
            printf("You need to specify a username!\nTry %s [username]\n", argv[0]);
            cl_exit(-1);
        } else {
            if (IsServerRunning(sv_fifo) == 0) {
                printf("Server is not online...\nPlease try another time.\n");
                cl_exit(-1);
            } else {
                // Server is online.. try to connect
                char cl_fifo[10];
                int pid = getpid();
                char cl_pid[10];
                sprintf(cl_pid, "%d", pid);
                strcpy(cl_fifo, "/tmp/");
                strcat(cl_fifo, cl_pid);
                //printf("%s\n", cl_fifo);
                if (mkfifo(cl_fifo, 0666) == 0) {
                    printf("Named pipe created.");
                    int fd = open(cl_fifo, O_RDONLY);
                    if (fd == -1) {
                        printf("Error opening named pipe.");
                        cl_exit(-1);
                    } else {
                        printf("Named pipe opened.");

                        // xassus agora

                        close(fd);
                        printf("Named pipe closed.");
                        unlink(cl_fifo);
                        printf("Named pipe deleted.");
                    }
                } else {
                    printf("An error occurred trying to open named pipe!\nClosing...");
                    cl_exit(-1);
                }
            }
        }
        cl_exit(0);

}

void cl_exit(int return_val) {


    exit(return_val);
}
