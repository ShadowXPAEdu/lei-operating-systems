

void cl_exit(int return_val);
